import logo from "./logo.svg";
import "./App.css";
import React, { FC, useMemo, useState } from "react";
import { Container } from "@mui/material";
import { TextField } from "@mui/material";
import { Button } from "@mui/material";
import {
  ConnectionProvider,
  WalletProvider,
} from "@solana/wallet-adapter-react";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
//import { UnsafeBurnerWalletAdapter } from '@solana/wallet-adapter-wallets';
import { PhantomWalletAdapter } from "@solana/wallet-adapter-phantom";
import { SolongWalletAdapter } from "@solana/wallet-adapter-solong";
import {
  WalletModalProvider,
  WalletDisconnectButton,
  WalletModalButton,
  WalletMultiButton,
} from "@solana/wallet-adapter-react-ui";
import {
  clusterApiUrl,
  LAMPORTS_PER_SOL,
  SystemProgram,
  PublicKey,
  VersionedTransaction,
  TransactionMessage,
} from "@solana/web3.js";
import {
  useConnection,
  useWallet,
  ConnectionContext,
  WalletContext,
} from "@solana/wallet-adapter-react";

require("@solana/wallet-adapter-react-ui/styles.css");

function AppContent() {
  const [toPublicKey, setToPublicKey] = useState(
    "CZmVK1DymrSVWHiQCGXx6VG5zgHVrh5J1P514jHKRDxA"
  );
  const [toCount, setToCount] = useState(10000000);
  const network = WalletAdapterNetwork.Testnet;
  const endpoint = clusterApiUrl(network);
  const wallets = [new SolongWalletAdapter(), new PhantomWalletAdapter()];
  const { connection } = useConnection();
  const { publicKey, sendTransaction } = useWallet();

  const onToPublicKey = (e) => {
    setToPublicKey(e.target.value)
  };

  const onToCount = (e) => {
    setToCount(e.target.value* LAMPORTS_PER_SOL)
  };

  const onTransfer = async () => {
    console.log("connection:", connection);
    console.log("publicKey:", publicKey);
    const txInstructions = [
      SystemProgram.transfer({
        fromPubkey: publicKey, //this.publicKey,
        toPubkey: new PublicKey(this.state.toPublicKey), //destination,
        lamports: this.state.toCount, //amount,
      }),
    ];
    console.log("instructions:", txInstructions);
    const {
      context: { slot: minContextSlot },
      value: { latestBlockhash, lastValidBlockHeight },
    } = await connection.getLatestBlockhashAndContext();
    console.log("lastest blockhash:", latestBlockhash);
    const messageV0 = new TransactionMessage({
      payerKey: publicKey,
      recentBlockhash: latestBlockhash.blockhash,
      instructions: txInstructions,
    }).compileToV0Message();

    const trx = new VersionedTransaction(messageV0);
    const signature = await sendTransaction(trx, connection, {
      minContextSlot,
    });
    console.log("signature:", signature);
  };

  return (
    <Container>
      <React.Fragment>
        <ConnectionProvider endpoint={endpoint}>
          <WalletProvider wallets={wallets} autoConnect>
            <WalletModalProvider>
              <WalletMultiButton />
              <WalletDisconnectButton />
            </WalletModalProvider>
          </WalletProvider>
        </ConnectionProvider>
      </React.Fragment>
      <React.Fragment>
        <TextField label="To" onChange={onToPublicKey} />
        <TextField label="Count" onChange={onToCount} />
        <Button onClick={onTransfer}> Transfer </Button>
      </React.Fragment>
    </Container>
  );
}

function App() {
  const { connection } = useConnection();
  const { publicKey, sendTransaction } = useWallet();
  return <AppContent />;
}

export default App;
