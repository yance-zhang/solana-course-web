import "./App.css";
import HomePage from "./pages/home";

export default function App() {
  return <HomePage />;
}
